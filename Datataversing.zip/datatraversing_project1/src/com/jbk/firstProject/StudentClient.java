package com.jbk.firstProject;
import java.util.ArrayList;
public class StudentClient {

	public static void main(String[] args)throws Exception{
		
			ArrayList<Student>all=StudentService.fetchStudent();
			for(Student alls:all) {
				System.out.println(alls.Studid);
				System.out.println(alls.Studnm);
			}
			
			
		 

	}

}
