package com.jbk.firstProject;
import java.util.ArrayList;
public class StudentService {
	
	static ArrayList<Student>fetchStudent() throws Exception{
		
         ArrayList<Student>allst= StudentController.fetchStudent();
         
         
         for(Student data:allst) {
        	 if(!data.Studnm.startsWith("A")) {
        		 
        	 System.out.println(data.Studid);
        	 System.out.println(data.Studnm);
         }}
         return allst;
	

	}
}