package com.jbk.firstProject;

public class Student {
	int Studid;
	String Studnm;
	public Student(int studid, String studnm) {
		super();
		Studid = studid;
		Studnm = studnm;
	}
	public int getStudid() {
		return Studid;
	}
	public void setStudid(int studid) {
		Studid = studid;
	}
	public String getStudnm() {
		return Studnm;
	}
	public void setStudnm(String studnm) {
		Studnm = studnm;
	}
	@Override
	public String toString() {
		return "Student [Studid=" + Studid + ", Studnm=" + Studnm + "]";
	}
	
	

}
