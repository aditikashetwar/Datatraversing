package com.jbk.firstProject;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
public class StudentDao {
	static ArrayList<Student> fetchStudent()throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		String sql="select * from student";
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		ArrayList<Student>allstud=new ArrayList<Student>();
		
		while(rs.next()) {
			int studid=rs.getInt(1);
			String studnm=rs.getString(2);
			
			Student stu=new Student(studid,studnm);
			System.out.println("studid="+studid);
			System.out.println("Studnm="+studnm);
			
		}
		
		return allstud;//here we hv to return object of arraylist as we return the object resultset then it may be closed when connection will closed
	}

}
